CREATE TABLE Roles (
	id SERIAL PRIMARY KEY,
	nombre VARCHAR(50)
);

CREATE TABLE Permisos (
    id SERIAL PRIMARY KEY,
	fk_rol INT NOT NULL REFERENCES Roles(id), 
    nombre VARCHAR(50) NOT NULL
);

CREATE TABLE Roles_Permisos (
	fk_rol INT NOT NULL REFERENCES Roles(id),
	fk_permiso INT NOT NULL REFERENCES Permisos(id),
	PRIMARY KEY (fk_rol, fk_permiso)
);

CREATE TABLE Suscripcion (
	id SERIAL PRIMARY KEY,
	nombre VARCHAR(50) NOT NULL UNIQUE,
	precio_mensual NUMERIC(10,2),
	limite_usuarios INT,
	limite_facturas_mensuales INT,
	limite_establecimientos INT
);
	
CREATE TABLE Modulos_Suscripcion (
    id SERIAL PRIMARY KEY,
    fk_suscripcion INT NOT NULL REFERENCES Suscripcion(id),
    nombre_modulo VARCHAR(50) NOT NULL, 
    CONSTRAINT unique_suscripcion_modulo UNIQUE (fk_suscripcion, nombre_modulo)
);

CREATE TABLE Usuarios (
	id SERIAL PRIMARY KEY,
	fk_rol INT NOT NULL REFERENCES Roles(id), 
	fk_suscripcion INT NOT NULL REFERENCES Suscripcion(id), 
	usuario VARCHAR(50) NOT NULL UNIQUE,
	contrasena TEXT NOT NULL,
	correo VARCHAR(50) UNIQUE
);

CREATE TABLE Clientes (
	id SERIAL PRIMARY KEY,
	nombre VARCHAR(100) NOT NULL, 
	num_identificacion VARCHAR(13) NOT NULL UNIQUE, 
	celular VARCHAR(13), 
	direccion VARCHAR(250), 
	correo VARCHAR(100),
	tipo_cliente VARCHAR(10) CHECK (tipo_cliente IN ('NATURAL','JURIDICA')) 
);

CREATE TABLE Proveedores (
	id SERIAL PRIMARY KEY,
	nombre VARCHAR(100) NOT NULL,
	ruc VARCHAR(13) NOT NULL UNIQUE,
	direccion VARCHAR(250),
	telefono VARCHAR(13)
);

CREATE TABLE Productos (
	id SERIAL PRIMARY KEY,
	fk_proveedor INT REFERENCES Proveedores(id), 
	nombre_producto VARCHAR(50) NOT NULL,
	descripcion VARCHAR(200),
	costo_unitario NUMERIC(10,2) NOT NULL,
	stock INT NOT NULL DEFAULT 0,
	codigo_producto VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE Tipos_Movimiento (
	id SERIAL PRIMARY KEY,
	nombre VARCHAR(20) NOT NULL UNIQUE CHECK (nombre IN ('COMPRA', 'VENTA', 'DEVOLUCION'))
);

CREATE TABLE Unidades_Medida (
	id SERIAL PRIMARY KEY,
	nombre VARCHAR(20) NOT NULL UNIQUE CHECK (nombre IN ('UNIDAD','CAJA','BULTO','KILO', 'METRO', 'LITRO'))
);

CREATE TABLE Inventario (
	id SERIAL PRIMARY KEY,
	fk_producto INT NOT NULL REFERENCES Productos(id),
	fk_tipo_movimiento INT NOT NULL REFERENCES Tipos_Movimiento(id),
	fk_unidad_medida INT NOT NULL REFERENCES Unidades_Medida(id),
	cantidad INT NOT NULL,
	fecha DATE NOT NULL DEFAULT CURRENT_DATE, 
	estado VARCHAR(15) NOT NULL CHECK (estado IN ('DISPONIBLE', 'RESERVADO', 'DAÑADO', 'EN_TRANSITO')),
	ubicacion_fisica VARCHAR(50)
);

CREATE TABLE Facturacion_Basica (
	id SERIAL PRIMARY KEY,
	fk_cliente INT NOT NULL REFERENCES Clientes(id),	
	num_factura VARCHAR(50) UNIQUE,
	nombre_emisor VARCHAR(50),
	nombre_receptor VARCHAR(50),
	fecha_expedicion DATE NOT NULL DEFAULT CURRENT_DATE,
	fecha_vencimiento DATE,
	descripcion VARCHAR (500),
	base_imponible NUMERIC(10,2) NOT NULL,
	iva NUMERIC(10,2) DEFAULT 0.00,
	descuentos NUMERIC(10,2) DEFAULT 0.00,
	total NUMERIC(10,2) NOT NULL,
	forma_pago VARCHAR(15) NOT NULL CHECK (forma_pago IN ('EFECTIVO','TRANSFERENCIA','TARJETA', 'CREDITO')),
	comentarios VARCHAR(500)
);

CREATE TABLE Liquidacion_Compras (
	id SERIAL PRIMARY KEY, 
	nombre_proveedor VARCHAR(150), 
    direccion_proveedor VARCHAR(250),
	fecha_emision DATE NOT NULL DEFAULT CURRENT_DATE,
    base_imponible NUMERIC(10, 2) NOT NULL,
    iva NUMERIC(10, 2) DEFAULT 0.00,
    retenciones NUMERIC(10, 2) DEFAULT 0.00,
    valor_total NUMERIC(10, 2) NOT NULL, 
    forma_pago VARCHAR(50) NOT NULL,
    plazo VARCHAR(20),
    numeracion_autorizada VARCHAR(15) UNIQUE,
	reembolsos_de_gastos BOOLEAN DEFAULT FALSE
);

CREATE TABLE Detalle_Liquidacion_Compras (
	id SERIAL PRIMARY KEY,
	fk_liquidacion INT NOT NULL REFERENCES Liquidacion_Compras(id),
	descripcion TEXT NOT NULL,
    cantidades NUMERIC(10, 4) NOT NULL,
    valor_unitario NUMERIC(10, 2) NOT NULL,
    valor_total_linea NUMERIC(10, 2) NOT NULL
);

CREATE TABLE Retenciones (
	id SERIAL PRIMARY KEY,
	base_imponible NUMERIC(10,2) NOT NULL,
	porcentaje_retencion NUMERIC(10,2) NOT NULL,
	motivo VARCHAR(500),
	monto_retenido NUMERIC(10,2) NOT NULL,
	impuestos_adicionales NUMERIC(10,2) DEFAULT 0.00,
	detalles_comprobante JSONB
);

CREATE TABLE Guias_Remision (
	id SERIAL PRIMARY KEY,
	fk_factura INT REFERENCES Facturacion_Basica(id), 
	fk_cliente INT NOT NULL REFERENCES Clientes(id), 
	tipo_identificacion VARCHAR(10) NOT NULL CHECK (tipo_identificacion IN ('CEDULA','RUC','PASAPORTE')),
	num_identificacion VARCHAR(13) NOT NULL,
	domicilio_fiscal VARCHAR(50),
	lugar_origen VARCHAR(100) NOT NULL,
	lugar_destino VARCHAR(100) NOT NULL,
	motivo_traslado VARCHAR(500) NOT NULL,
	medio_transporte VARCHAR(10) NOT NULL CHECK (medio_transporte IN ('CAMION','AVION','BARCO', 'MOTO')),
	mercancia_descripcion_detallada VARCHAR(150),
	numero_comprobante VARCHAR(50) UNIQUE,
	fecha_emision DATE NOT NULL DEFAULT CURRENT_DATE,
	fecha_vencimiento DATE,
	ruta VARCHAR (500),
	estado_documento VARCHAR(15) NOT NULL CHECK (estado_documento IN ('EMITIDA','EN REVISION','CANCELADA', 'ENTREGADA')),
	firma_electronica BYTEA
);
	
CREATE TABLE Notas_Credito (
	id SERIAL PRIMARY KEY, 
	fk_factura_basica INT NOT NULL REFERENCES Facturacion_Basica(id), 
	nombre_cliente VARCHAR(100), 
	direccion VARCHAR(250),
	num_identificacion VARCHAR(13),
	fecha_emision DATE NOT NULL DEFAULT CURRENT_DATE,
	motivo VARCHAR(500) NOT NULL,
	importe_total NUMERIC(10,2) NOT NULL
);

CREATE TABLE Detalle_Nota_Credito (
	id SERIAL PRIMARY KEY,
	fk_nota_credito INT NOT NULL REFERENCES Notas_Credito(id),
	fk_producto INT REFERENCES Productos(id),
	cantidad INT NOT NULL,
	valor_ajustado NUMERIC(10,2) NOT NULL
);

CREATE TABLE Contabilidad (
	id SERIAL PRIMARY KEY,
	fecha_transaccion DATE NOT NULL DEFAULT CURRENT_DATE,
	descripcion TEXT,
	num_identificacion VARCHAR(13),
	monto_debe NUMERIC(10,2) NOT NULL DEFAULT 0.00,
	monto_haber NUMERIC(10,2) NOT NULL DEFAULT 0.00,
	fk_factura INT REFERENCES Facturacion_Basica(id),
	fk_liquidacion INT REFERENCES Liquidacion_Compras(id)
);

CREATE TABLE Detalle_Factura (
    id SERIAL PRIMARY KEY,
    fk_factura_basica INT NOT NULL REFERENCES Facturacion_Basica(id), 
    fk_producto INT NOT NULL REFERENCES Productos(id), 
    cantidad INT NOT NULL,
    valor_unitario NUMERIC(10,2) NOT NULL,
    subtotal NUMERIC(10,2) NOT NULL,
	UNIQUE (fk_factura_basica, fk_producto)
);

CREATE TABLE Facturacion_Programada (
	id SERIAL PRIMARY KEY,
	fk_cliente INT NOT NULL REFERENCES Clientes(id), 
	fk_factura_basica INT NOT NULL REFERENCES Facturacion_Basica(id), 
	frecuencia VARCHAR(15) NOT NULL CHECK (frecuencia IN ('MENSUAL','TRIMESTRAL','ANUAL')), 
	estado VARCHAR(15) NOT NULL CHECK (estado IN ('ACTIVA','PAUSADA','FINALIZADA')),
	fecha_inicio DATE NOT NULL,
	fecha_fin DATE
);

CREATE TABLE Reportes_Basicos (
	id SERIAL PRIMARY KEY,
	fk_factura_basica INT REFERENCES Facturacion_Basica(id), 
	fk_retencion INT REFERENCES Retenciones(id), 
	fk_nota_credito INT REFERENCES Notas_Credito(id), 
	nombre_emisor VARCHAR(50),
	nombre_cliente VARCHAR(50),
	direccion_emisor VARCHAR(100),
	direccion_cliente VARCHAR(100),
	abono_realizado NUMERIC(10,2),
	fecha_abono DATE,
	saldo_pendiente NUMERIC(10,2),
	num_autorizacion VARCHAR(50),
	firma_electronica BYTEA
);

CREATE TABLE Reportes_Avanzados (
	id SERIAL PRIMARY KEY,
	fk_nota_credito INT REFERENCES Notas_Credito(id), 
	cargos_detallados JSONB,
	transacciones_detalladas JSONB,
	informacion_adicional JSONB	
);